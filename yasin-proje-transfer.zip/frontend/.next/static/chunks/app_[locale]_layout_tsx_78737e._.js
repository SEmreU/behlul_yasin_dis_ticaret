(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_layout_tsx_78737e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_layout_tsx_78737e._.js",
  "chunks": [
    "static/chunks/node_modules_247368._.js",
    "static/chunks/_5d7811._.js"
  ],
  "source": "dynamic"
});
